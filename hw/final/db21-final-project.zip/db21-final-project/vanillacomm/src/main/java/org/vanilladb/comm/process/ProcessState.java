package org.vanilladb.comm.process;

public enum ProcessState {
	UNINITIALIZED, CORRECT, FAILED
}
