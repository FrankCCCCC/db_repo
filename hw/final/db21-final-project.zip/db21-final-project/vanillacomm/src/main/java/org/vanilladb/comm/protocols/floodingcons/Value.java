package org.vanilladb.comm.protocols.floodingcons;

import java.io.Serializable;

public interface Value extends Serializable, Comparable<Value> {

}
