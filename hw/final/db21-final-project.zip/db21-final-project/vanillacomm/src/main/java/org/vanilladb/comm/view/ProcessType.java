package org.vanilladb.comm.view;

public enum ProcessType {
	SERVER, CLIENT
}
