package org.elasql.remote.groupcomm.client;

public interface DirectMessageListener {
	void onReceivedDirectMessage(Object message);
}
