package org.elasql.migration.mgcrab;

public enum BgPushPhases {
	PHASE1, PHASE2, PIPELINING
}
